<?php
  require 'views/currentcapital.view.php';