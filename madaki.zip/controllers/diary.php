<?php
  require 'views/diary.view.php';