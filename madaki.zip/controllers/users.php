<?php
    require 'views/users.view.php';
?>