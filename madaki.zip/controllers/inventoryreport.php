<?php
    require 'views/inventoryreport.view.php';
?>