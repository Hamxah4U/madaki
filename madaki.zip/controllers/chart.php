<?php
  require 'views/chart.view.php'
?>