<?php
    require 'views/animal.view.php'
?>