<?php
    require 'views/individualrecord.view2.php'
?>