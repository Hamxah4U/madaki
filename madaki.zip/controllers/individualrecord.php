<?php
    require 'views/individualrecord.view.php'
?>