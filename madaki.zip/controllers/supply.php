<?php
    require 'views/supply.php';
?>