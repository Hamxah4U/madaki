<?php
    require 'views/viewstore.view.php';
?>