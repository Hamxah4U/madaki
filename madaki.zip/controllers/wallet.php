<?php
    require 'views/wallet.view.php';
?>