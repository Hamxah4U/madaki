<?php
    require 'views/report.view.php';
?>