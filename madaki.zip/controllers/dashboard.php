<?php
  require 'views/dashboard.view.php';