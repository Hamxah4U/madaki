<?php
require_once 'model/Database.php';

// Validate parameters
if (!isset($_GET['id']) || empty($_GET['id']) || !isset($_GET['tid']) || empty($_GET['tid'])) {
    require 'controllers/404.php';
    exit();
}

$id = (int)$_GET['id'];
$tid = (int)$_GET['tid'];

// Fetch customer/person transportation expense record
$stmt = $db->conn->prepare("SELECT te.*, c.fullname AS customer_name, c.phone AS customer_phone 
                            FROM transportation_expenses te 
                            LEFT JOIN customers_tbl c ON c.id = te.customer_id 
                            WHERE te.id = ?");
$stmt->execute([$id]);
$person = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$person) {
    echo "Receipt record not found.";
    exit();
}

// Fetch transportation & driver info
$stmt2 = $db->conn->prepare("SELECT * FROM transportation WHERE id=?");
$stmt2->execute([$tid]);
$transport = $stmt2->fetch(PDO::FETCH_ASSOC);

// Calculate total surviving animals and cost per animal
$stmt3 = $db->conn->prepare("SELECT SUM(surviving_animal) as total_surviving FROM transportation_expenses WHERE transportation_id=?");
$stmt3->execute([$tid]);
$totalSurvivingData = $stmt3->fetch(PDO::FETCH_ASSOC);
$totalSurviving = $totalSurvivingData['total_surviving'] ?? 0;

$driverAmount = $transport['driver_amount'] ?? 0;
$costPerAnimal = $totalSurviving > 0 ? $driverAmount / $totalSurviving : 0;

// Render a clean, standalone public receipt view
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Payment Receipt - Bashir Madaki Transport</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css">
    <style>
        body { background: #f8f9fa; padding: 30px; font-family: Arial, sans-serif; }
        .receipt-card { max-width: 600px; margin: 0 auto; background: #fff; padding: 30px; border-radius: 8px; box-shadow: 0 0 15px rgba(0,0,0,0.1); }
        .print-header h3 { margin-bottom: 5px; font-weight: bold; color: #333; }
    </style>
</head>
<body>
    <div class="receipt-card">
        <div class="text-center mb-4">
            <h3>BASHIR MADAKI TRANSPORT</h3>
            <p class="text-muted mb-0">Transportation Payment Receipt</p>
            <small>Date: <?= date('d M Y') ?></small>
        </div>

        <table class="table table-bordered">
            <tr>
                <th>Customer Name</th>
                <td><?= htmlspecialchars($person['customer_name'] ?? $person['fullname']) ?></td>
            </tr>
            <tr>
                <th>Driver Name</th>
                <td><?= htmlspecialchars($transport['driver_name'] ?? 'N/A') ?></td>
            </tr>
            <tr>
                <th>Motor No</th>
                <td><?= htmlspecialchars($transport['bossno'] ?? 'N/A') ?></td>
            </tr>
            <tr>
                <th>Yan Waju</th>
                <td><?= htmlspecialchars($transport['yan_waju'] ?? 'N/A') ?></td>
            </tr>
            <tr>
                <th>Survived Animals</th>
                <td><?= (int)$person['surviving_animal'] ?></td>
            </tr>
            <tr>
                <th>Cost per Animal</th>
                <td>₦<?= number_format($costPerAnimal, 2) ?></td>
            </tr>
            <tr>
                <th>Expected Amount</th>
                <td>
                    <?php $expectedTotal = (int)$person['surviving_animal'] * $costPerAnimal; ?>
                    ₦<?= number_format($expectedTotal, 2) ?>
                </td>
            </tr>
            <tr>
                <th>1st Payment</th>
                <td>₦<?= number_format($person['first_payment'] ?? 0, 2) ?></td>
            </tr>
            <tr>
                <th>2nd Payment</th>
                <td>₦<?= number_format($person['second_payment'] ?? 0, 2) ?></td>
            </tr>
            <tr>
                <th>3rd Payment</th>
                <td>₦<?= number_format($person['third_payment'] ?? 0, 2) ?></td>
            </tr>
            <tr>
                <th>Total Paid</th>
                <td><strong class="text-success">₦<?= number_format($person['total'] ?? 0, 2) ?></strong></td>
            </tr>
            <tr>
                <th>Status / Balance</th>
                <td>
                    <?php $balanceT = $expectedTotal - (float)$person['total']; ?>
                    <?php if($balanceT > 0): ?>
                        <span class="text-warning">₦<?= number_format($balanceT, 2) ?> Remaining</span>
                    <?php elseif($balanceT < 0): ?>
                        <span class="text-info">₦<?= number_format(abs($balanceT), 2) ?> Overpaid</span>
                    <?php else: ?>
                        <span class="text-primary font-weight-bold">Cleared</span>
                    <?php endif; ?>
                </td>
            </tr>
        </table>

        <div class="text-center mt-4 no-print">
            <button onclick="window.print()" class="btn btn-primary px-4">Print / Save as PDF</button>
        </div>
    </div>
</body>
</html>



<?php


// require 'model/Database.php';


// $id = $_GET['id'];
// $tid = $_GET['tid'];

// $stmt = $db->conn->prepare("SELECT * FROM transportation_expenses WHERE id=?");
// $stmt->execute([$id]);
// $person = $stmt->fetch(PDO::FETCH_ASSOC);

// $stmt2 = $db->conn->prepare("SELECT * FROM transportation WHERE id=?");
// $stmt2->execute([$tid]);
// $transport = $stmt2->fetch(PDO::FETCH_ASSOC);

// require 'views/receipt.view.php';
