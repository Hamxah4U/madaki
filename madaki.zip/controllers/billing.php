<?php
    require 'views/billing.view.php';
?>