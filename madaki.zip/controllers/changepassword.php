<?php
    require 'views/changepassword.view.php';
?>