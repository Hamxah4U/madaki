<?php
require_once 'Database.php';
require_once 'vendor/autoload.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $errors = [];

    $comment = trim($_POST['comment'] ?? '');
    $userID  = trim($_POST['transport_id'] ?? '');
    $mode    = $_POST['mode'] ?? 'add';
    $id      = $_POST['id'] ?? null;
    $fstatus = $_POST['fstatus'] ?? null;

    // =========================
    // VALIDATION
    // =========================
    if (empty($comment)) {
        $errors['comment'] = 'Diary note is required!';
    }

    if (empty($userID)) {
        $errors['transport_id'] = 'Transport ID is required!';
    }

    if (empty($fstatus)) {
        $errors['fstatus'] = 'FStatus is required!';
    }

    if ($mode === 'edit' && empty($id)) {
        $errors['general'] = 'Invalid ID!';
    }

    if (!empty($errors)) {
        echo json_encode([
            'status' => false,
            'errors' => $errors
        ]);
        exit;
    }

    try {
        // $db = new Database();

        // =========================
        // ADD
        // =========================
        if ($mode === 'add') {

            $stmt = $db->conn->prepare("
                INSERT INTO expenses 
                (driver_id, reason, daterecorded, timerecorded, status, fstatus) 
                VALUES (:driver_id, :reason, CURDATE(), CURTIME(), 'diary', :fstatus)
            ");

            $stmt->execute([
                ':driver_id' => $userID,
                ':reason'    => $comment,
                ':fstatus'   => $fstatus
            ]);

            echo json_encode([
                'status' => true,
                'success' => ['message' => 'Diary added successfully.']
            ]);
            exit;
        }

        // =========================
        // UPDATE
        // =========================
        if ($mode === 'edit') {

            $check = $db->conn->prepare("
                SELECT id FROM expenses 
                WHERE id = :id AND status = 'diary'
            ");
            $check->execute([':id' => $id]);

            if ($check->rowCount() === 0) {
                echo json_encode([
                    'status' => false,
                    'errors' => ['general' => 'Diary not found']
                ]);
                exit;
            }

            $stmt = $db->conn->prepare("
                UPDATE expenses 
                SET reason = :reason 
                WHERE id = :id AND status = 'diary'
            ");

            $stmt->execute([
                ':reason' => $comment,
                ':id'     => $id
            ]);

            echo json_encode([
                'status' => true,
                'success' => ['message' => 'Diary updated successfully.']
            ]);
            exit;
        }

        echo json_encode([
            'status' => false,
            'errors' => ['general' => 'Invalid mode']
        ]);
        exit;

    } catch (PDOException $e) {
        echo json_encode([
            'status' => false,
            'errors' => ['general' => $e->getMessage()]
        ]);
        exit;
    }
}