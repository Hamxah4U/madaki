<style>
    strong{
        font-size: 12pt;
        font-family: Verdana, Geneva, Tahoma, sans-serif;
    }
</style>
<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

    <!-- Sidebar - Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="/dashboard">
        <div class="sidebar-brand-icon rotate-n-15">
            <i class="fas fa-laugh-win">ssss</i>
        </div>
        <div class="sidebar-brand-text mx-3">
            <!-- Smart billing -->
            <img src="../../img/ansar.png" alt="" style="width: 30%;">
        </div>
    </a>  

    <!-- Divider -->
    <hr class="sidebar-divider my-0">

    <!-- Nav Item - Dashboard -->
    <li class="nav-item active">
        <a class="nav-link" href="/dashboard">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <strong>Dashboard</strong></a>
    </li>
   
    <!-- Nav Item - Pages Collapse Menu -->
     <?php  if($_SESSION['role'] == 'Admin'):?>   
        
                <li class="nav-item">
                    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseAdmin"
                        aria-expanded="true" aria-controls="collapseAdmin">
                        <i class="fas fa-user-shield"></i>
                        <span></i> <strong>Admin</strong></span>
                    </a>
                    <div id="collapseAdmin" class="collapse" aria-labelledby="headingAdmin" data-parent="#accordionSidebar">
                        <div class="bg-white py-2 collapse-inner rounded">
                            <a class="collapse-item" href="/users"><strong>Manage Users</strong></a>
                            <a class="collapse-item" href="/manage-drivers"><strong>Manage Driver</strong></a>
                            <a class="collapse-item" href="/manage-agent"><strong>Manage Agent</strong></a>
                            <a class="collapse-item" href="/manage-market"><strong>Manage Market</strong></a>
                            <a class="collapse-item" href="/manage-customers"><strong>Customers</strong></a>
                        </div>
                    </div>
                </li>
              
                <?php if($_SESSION['role'] == 'Viewer 2'):?>
                <li class="nav-item active">
                    <a class="nav-link" href="/transportation">
                        <i class="fas fa-truck"></i>
                       <strong>Transportation</strong>
                    </a>
                </li>
                <?php endif ?>

                <li class="nav-item active">
                    <a class="nav-link" href="/transportation">
                        <i class="fas fa-truck"></i>
                       <strong>Transportation</strong>
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo"
                        aria-expanded="true" aria-controls="collapseTwo">
                        <i class="fas fa-truck"></i></i><strong>Motor Status</strong>
                    </a>
                    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                        <div class="bg-white py-2 collapse-inner rounded">
                            <a class="collapse-item" href="/onview"><strong>On View</strong></a>
                            <a class="collapse-item" href="/completed"><strong>Completed</strong></a>
                            <a class="collapse-item" href="/over"><strong>Over</strong></a>
                            <a class="collapse-item" href="/short"><strong>Short</strong></a>
                        </div>
                    </div>
                </li>
                
                <li class="nav-item active">
                    <a class="nav-link" href="/market">
                        <i class="fas fa-warehouse"></i>
                       <strong>Manage Market</strong>
                    </a>
                </li>   

                 <li class="nav-item active">
                    <a class="nav-link" href="/closed-market">
                        <i class="fas fa-warehouse"></i>
                       <strong>Closed Market</strong>
                    </a>
                </li>   


            <?php else: ?>
                <li class="nav-item active">
                     <a class="nav-link" href="#" onclick="denyAccess(); return false;">
                        <i class="fas fa-fw fa-user"></i>
                        <strong>Manage Users </strong></a>
                </li>

                <li class="nav-item active">
                     <a class="nav-link" href="#" onclick="denyAccess(); return false;">
                       <i class="fas fa-fw fa-id-card"></i>
                        <strong>Manage Driver </strong></a>
                </li>
              

                <li class="nav-item active">
                    <a class="nav-link" href="/agent-transportation">
                        <i class="fas fa-truck"></i>
                       <strong>Transportation</strong>
                    </a>
                </li>   
                
                <li class="nav-item active">
                    <a class="nav-link" href="/market">
                        <i class="fas fa-warehouse"></i>
                       <strong>Manage Market</strong>
                    </a>
                </li> 
            <?php endif; ?>

           

            <hr class="sidebar-divider my-0">
            <li class="nav-item active">
                <a class="nav-link" href="/logout">
                    <i class="fas fa-sign-out-alt text-danger"></i>
                    <strong class="text-danger">Logout</strong>
                </a>
            </li>


    <!-- Sidebar Toggler (Sidebar) -->
    <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
    </div>

            <!-- Sidebar Message -->
</ul>

<script>
    function denyAccess() {
        Swal.fire({
            icon: 'warning',
            title: 'Access Denied',
            text: 'You do not have permission to access this section.',
            timer: 2500,
            showConfirmButton: false
        });
    }
</script>