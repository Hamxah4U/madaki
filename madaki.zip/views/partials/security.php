<?php
    // session_start();
    // if (!isset($_SESSION['userID']) || !isset($_SESSION['email'])) {
    //     header('Location: /');
    //     exit();
    // }

    // session_start();
    // if (!isset($_SESSION['userID']) || !isset($_SESSION['email'])) {
    //     header('Location: /');
    //     exit();
    // }
?>